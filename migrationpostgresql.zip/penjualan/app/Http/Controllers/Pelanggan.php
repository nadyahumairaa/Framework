<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Pelanggan extends Controller
{
    function index(){
        return view('pelanggan/index');
    }

    function form(){
        return view('pelanggan/form');
    }

    function simpan(Request $req){
        $nama=$req->namapelanggan;
        $umur=$req->usia;
        $keterangan=$req->ket;

        $data=array(
            'namapelanggan'=>$nama,
            'usia'=>$umur,
            'ket'=>$keterangan
        );
        return view('pelanggan/simpan',$data);
    }
}
