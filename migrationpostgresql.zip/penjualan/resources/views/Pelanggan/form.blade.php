<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
    <form method="POST" action="{{url('pelanggan/simpan')}}">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
            Nama :<input type="text" name="namapelanggan"><br>
            Umur :<input type="text" name="usia"><br>
        <input type="submit" value="Simpan">
    </form>
</body>
</html>