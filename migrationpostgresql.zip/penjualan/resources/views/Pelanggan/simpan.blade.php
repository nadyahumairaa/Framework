Nama : {{$namapelanggan}}<br>
Umur : {{$usia}}<br>

@if($usia <=12)
    Keterangan = Anak-Anak
@elseif($usia >12 and $usia <=17)
    Keterangan = Remaja
@elseif($usia >17 and $usia <=22)
    Keterangan = Dewasa Muda
@elseif($usia >22 and $usia <=35)
    Keterangan = Dewasa Matang
@else($usia =>35)
    Keterangan = Tua
@endif

@for ($ket =1; $ket <=$usia; $ket++)
    {{$ket}}<br>
@endfor