<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
    <form method="POST" action="<?php echo e(url('pelanggan/simpan')); ?>">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            Nama :<input type="text" name="namapelanggan"><br>
            Umur :<input type="text" name="usia"><br>
        <input type="submit" value="Simpan">
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\penjualan\resources\views/pelanggan/form.blade.php ENDPATH**/ ?>