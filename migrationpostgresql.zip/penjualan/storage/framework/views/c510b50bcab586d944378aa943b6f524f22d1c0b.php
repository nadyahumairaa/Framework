Nama : <?php echo e($namapelanggan); ?><br>
Umur : <?php echo e($usia); ?><br>

<?php if($usia <=12): ?>
    Keterangan = Anak-Anak
<?php elseif($usia >12 and $usia <=17): ?>
    Keterangan = Remaja
<?php elseif($usia >17 and $usia <=22): ?>
    Keterangan = Dewasa Muda
<?php elseif($usia >22 and $usia <=35): ?>
    Keterangan = Dewasa Matang
<?php else: ?>
    Keterangan = Tua
<?php endif; ?>

<?php for($ket =1; $ket <=$usia; $ket++): ?>
    <?php echo e($ket); ?><br>
<?php endfor; ?><?php /**PATH C:\xampp\htdocs\penjualan\resources\views/pelanggan/simpan.blade.php ENDPATH**/ ?>